CREATE TABLE [dbo].[Cliente] (
    [Id]             INT           IDENTITY (1, 1) NOT NULL,
    [Nome]           NVARCHAR (30) NOT NULL,
    [Cpf]            NVARCHAR (11) NOT NULL,
    [DataNascimento] DATETIME      NOT NULL,
    [IdEndereco]     INT           NOT NULL,
    CONSTRAINT [Pk_Cliente] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Endereco_ID] FOREIGN KEY ([IdEndereco]) REFERENCES [dbo].[Endereco] ([Id])
);



CREATE TABLE [dbo].[Endereco] (
    [Id]         INT           IDENTITY (1, 1) NOT NULL,
    [Logradouro] NVARCHAR (50) NOT NULL,
    [Bairro]     NVARCHAR (40) NOT NULL,
    [Cidade]     NVARCHAR (40) NOT NULL,
    [Estado]     NVARCHAR (40) NOT NULL,
    CONSTRAINT [Pk_Endereco] PRIMARY KEY CLUSTERED ([Id] ASC)
);